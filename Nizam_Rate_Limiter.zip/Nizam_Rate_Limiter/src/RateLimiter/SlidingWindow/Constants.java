package RateLimiter.SlidingWindow;

public class Constants {
    static final int TIME_WINDOW_IN_SECONDS = 10;
    static final int BUCKET_SIZE = 2;
    static final int NO_OF_THREADS = 3;
    static final int SLEEP_TIME_IN_SECONDS= 3;
}
