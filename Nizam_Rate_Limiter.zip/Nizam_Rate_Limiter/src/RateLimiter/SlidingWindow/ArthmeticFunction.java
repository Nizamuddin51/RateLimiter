package RateLimiter.SlidingWindow;

public interface ArthmeticFunction {
    Double call();
}
